from django.shortcuts import render, redirect, get_object_or_404
from customer.models import Customer, CustomerServiceRequest, CustomerQuery , UserFeedback
from wfmadmin.models import UserFeedback, Assignment, Worker, Userratereview, PaymentRequest, PaymentDetail, ChatMessage
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
import json

def customerloginpage(request):
    return render(request, 'customer/login.html')

def customerregistrationaction(request):
    if request.method == 'POST':
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        email = request.POST.get('email')
        password = request.POST.get('password')

        customer = Customer(firstname=firstname, lastname=lastname, email=email, password=password)
        customer.save()

        messages.success(request, "Registration successful.")
        return redirect('customerloginpage')
    return render(request, 'customer/register.html')
    
def customerloginaction(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            customer_obj = Customer.objects.get(email=email, password=password, status=True)
        except Customer.DoesNotExist:  # Changed to 'Customer.DoesNotExist'
            return render(request, 'customerloginpage.html', {'error': True})
        request.session['customer_id'] = customer_obj.id
        request.session['customer_username'] = customer_obj.username
        return redirect('customerprofile')
    else:
        return render(request, 'customerloginpage.html', {'error': True})
    
def customerlogout(request):
    return render(request, 'customerloginpage.html')
    
def customerprofile(request):
    customer_id = request.session.get('customer_id')
    if not customer_id:
        return redirect('customerloginpage')
    try:
        customer_obj = Customer.objects.get(id=customer_id)  # Changed 'customer' to 'Customer'
    except Customer.DoesNotExist:  # Changed to 'Customer.DoesNotExist'
        return redirect('customerloginpage')
    
    context = {
        'customer': customer_obj,
    }
    return render(request, 'customer/customerhome.html', context)

def update_customer_profile(request):
    customer_id = request.session.get('customer_id')
    if not customer_id:
        return redirect('customerloginpage')
    try:
        customer_obj = Customer.objects.get(id=customer_id)  # Changed 'customer' to 'Customer'
    except Customer.DoesNotExist:  # Changed to 'Customer.DoesNotExist'
        return redirect('customerloginpage')
    
    if request.method == 'POST':
        if 'firstname' in request.POST and request.POST['firstname']:
            customer_obj.firstname = request.POST['firstname']
        if 'lastname' in request.POST and request.POST['lastname']:
            customer_obj.lastname = request.POST['lastname']
        if 'address' in request.POST and request.POST['address']:
            customer_obj.address = request.POST['address']
        if 'city' in request.POST and request.POST['city']:
            customer_obj.city = request.POST['city']
        if 'state' in request.POST and request.POST['state']:
            customer_obj.state = request.POST['state']
        if 'country' in request.POST and request.POST['country']:
            customer_obj.country = request.POST['country']
        if 'username' in request.POST and request.POST['username']:
            customer_obj.username = request.POST['username']
        if 'email' in request.POST and request.POST['email']:
            customer_obj.email = request.POST['email']
        if 'number' in request.POST and request.POST['number']:
            customer_obj.number = request.POST['number']

        customer_obj.save()
        return redirect('customerprofile')
    else:
        return redirect('customerprofile')
    
def update_customer_profile_password(request):
    if request.method == 'POST':
        old_password = request.POST.get('oldpassword')
        new_password = request.POST.get('newpassword')
        cfrm_password = request.POST.get('confirm_password')

        customer_id = request.session.get('customer_id')
        current_customer = Customer.objects.get(id=customer_id)  # Changed 'customer' to 'Customer'

        if old_password != current_customer.password:
            messages.error(request, "Old password is incorrect.")
            return redirect('customerprofile')  

        if new_password != cfrm_password:
            messages.error(request, "New password and confirm password do not match.")
            return redirect('customerprofile') 
         
        current_customer.password = new_password
        current_customer.save()
        messages.success(request, "Password updated successfully.")
        return redirect('customerprofile') 
    return redirect('customerprofile') 

# Other views remain the same except references to 'customer' were replaced with 'Customer' or relevant fixes were made.
