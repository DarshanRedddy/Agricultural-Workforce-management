from django.apps import AppConfig


class WfmadminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'wfmadmin'
