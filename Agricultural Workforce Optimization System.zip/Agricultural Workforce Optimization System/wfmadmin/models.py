from django.db import models

class Assignment(models.Model):
    worker = models.ForeignKey('worker.Worker', on_delete=models.CASCADE)
    customer = models.ForeignKey('customer.Customer', on_delete=models.CASCADE)
    request = models.ForeignKey('customer.CustomerServiceRequest', on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    start = models.DateTimeField()
    end = models.DateTimeField()
    status = models.CharField(max_length=100, default='none')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.worker.username} assigned to {self.customer.username} for {self.request.service}"


class ChatMessage(models.Model):
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE)
    customer_sender = models.ForeignKey(
        'customer.Customer', null=True, blank=True, on_delete=models.CASCADE, related_name='sent_messages'
    )
    worker_sender = models.ForeignKey(
        'worker.Worker', null=True, blank=True, on_delete=models.CASCADE, related_name='received_messages'
    )
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Message from {self.customer_sender or self.worker_sender} at {self.timestamp}'


class Userratereview(models.Model):
    user = models.ForeignKey('customer.Customer', on_delete=models.CASCADE)
    worker = models.ForeignKey('worker.Worker', on_delete=models.CASCADE)
    rating = models.PositiveSmallIntegerField()
    review = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback by {self.user.username} for {self.worker.username} with rating {self.rating}"


class PaymentDetail(models.Model):
    payment_request = models.OneToOneField('worker.PaymentRequest', on_delete=models.CASCADE)
    utr_number = models.CharField(max_length=100)
    screenshot = models.ImageField(upload_to='payment_screenshots/')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Payment detail for {self.payment_request}"


class WorkReport(models.Model):
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE)
    worker = models.ForeignKey('worker.Worker', on_delete=models.CASCADE)
    report = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)


class WorkerTimeOffRequest(models.Model):
    id = models.AutoField(primary_key=True)
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE)
    time_off_duration = models.CharField(max_length=20)
    requested_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20)

    def __str__(self):
        return f"Time off request by {self.assignment.worker.username} for {self.time_off_duration}"



class UserFeedback(models.Model):
    customer = models.ForeignKey('customer.Customer', on_delete=models.CASCADE)
    feedback_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback by {self.customer.username}"
