from django.contrib import admin
from .models import Worker, WorkerProfile, WorkerQuery, PaymentRequest

# Registering all models
admin.site.register(Worker)
admin.site.register(WorkerProfile)
admin.site.register(WorkerQuery)
admin.site.register(PaymentRequest)
