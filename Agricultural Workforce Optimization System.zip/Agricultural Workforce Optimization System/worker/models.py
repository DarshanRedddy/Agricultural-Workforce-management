from django.db import models


class Worker(models.Model):
    username = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    contact = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    skills = models.TextField()
    status = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username


class WorkerProfile(models.Model):
    worker = models.OneToOneField(Worker, on_delete=models.CASCADE)
    bio = models.TextField()
    experience = models.IntegerField()
    profile_picture = models.ImageField(upload_to='worker_profiles/', null=True, blank=True)

    def __str__(self):
        return f"Profile of {self.worker.username}"


class WorkerQuery(models.Model):
    worker = models.ForeignKey('Worker', on_delete=models.CASCADE)
    query = models.TextField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Query by {self.worker.username} on {self.submitted_at.strftime('%Y-%m-%d %H:%M:%S')}"


class PaymentRequest(models.Model):
    worker = models.ForeignKey('Worker', on_delete=models.CASCADE, related_name='payment_requests')
    assignment = models.ForeignKey('wfmadmin.Assignment', on_delete=models.CASCADE, related_name='payment_requests')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=100, choices=[('pending', 'Pending'), ('approved', 'Approved'), ('rejected', 'Rejected')], default='pending')

    def __str__(self):
        return f"Payment Request: {self.amount} by {self.worker.username} ({self.status})"
